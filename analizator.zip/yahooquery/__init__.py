# ŚCIEŻKA: C:\Users\Msi\Desktop\analizator\yahooquery\__init__.py
"""
Minimalny stub dla 'yahooquery' wymagany przez testy,
tak aby można było patchować yahooquery.Ticker bez instalacji pakietu.
"""

class Ticker:  # pragma: no cover - wyłącznie na potrzeby importu/patchy
    def __init__(self, *args, **kwargs):
        pass
